<?php
/**
*
* @package phpBB Extension - Kirk New Topic Button in Topic
* @copyright (c) 2014 Kirk http://www.quad-atv-freunde-wunsiedel.de
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace kirk\new_topic_button_in_topic;

/**
* @ignore
*/

class ext extends \phpbb\extension\base
{
}