[![phpBB-SEO](http://www.php-bb.ir/pic/uploads/15303852777391.jpg)](http://www.phpBB-SEO.ir)

# usu ( Ultimate phpBB SEO Friendly URL )
Ultimate phpBB SEO Friendly URL
This Extension will URL rewrite phpBB URLs in various manners, injecting, or not, forums and topic titles in their URLS, each URL being rewritten once, no matter the number of links using it on the page.
You will be able to run the mod in Advanced, Mixed and Simple mode.

<b>Note:</b><br />
Report Bugs: https://github.com/phpbb-seo/usu/issues <br />

<b>Working on phpBB 3.2 & 3.3</b>

<b>Support Community:</b>
<br /> phpBB-SEO.ir/community/
