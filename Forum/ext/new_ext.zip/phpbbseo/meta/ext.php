<?php
/**
*
* @package Dynamic Meta Tags phpBB SEO
* @version $$
* @copyright (c) 2017 www.phpbb-seo.org
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace phpbbseo\meta;

/**
* ext Class
* www.phpBB-SEO.org
* @copyright (c) 2017 www.phpbb-seo.org
*/
class ext extends \phpbb\extension\base
{
}
