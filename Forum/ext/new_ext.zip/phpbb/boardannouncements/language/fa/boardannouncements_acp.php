<?php
/**
*
* Board Announcements extension for the phpBB Forum Software package.
*
* @copyright (c) 2014 phpBB Limited <https://www.phpbb.com>
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ » “ ” …
//

$lang = array_merge($lang, array(
	'BOARD_ANNOUNCEMENTS_SETTINGS'			=> 'تنظیمات اطلاعیه تالار',
	'BOARD_ANNOUNCEMENTS_SETTINGS_EXPLAIN'	=> ' در این قسمت شما میتوانید تنظیمات مربوط به اطلاعیه تالار را انجام داده و برای تالار خود اطلاعیه سراسری ساخته تا در تمامی صفحات به نمایش در آید.',

	'BOARD_ANNOUNCEMENTS_ENABLE'			=> 'نمایش اطلاعیه',
	'BOARD_ANNOUNCEMENTS_USERS'				=> 'چه کسانی قادر به مشاهده اطلاعیه باشند؟',
	'BOARD_ANNOUNCEMENTS_DISMISS'			=> 'مجوز به کاربران برای نادیده گرفتن اطلاعیه',

	'BOARD_ANNOUNCEMENTS_INDEX_ONLY'			=> 'نمایش در صفحه اصلی فقط',

	'BOARD_ANNOUNCEMENTS_EVERYONE'			=> 'همه',

	'BOARD_ANNOUNCEMENTS_BGCOLOR'			=> 'رنگ پس زمینه اطلاعیه',
	'BOARD_ANNOUNCEMENTS_BGCOLOR_EXPLAIN'	=> 'در این قسمت میتوانید رنگ پس زمینه اطلاعیه را انتخاب کنید.',

	'BOARD_ANNOUNCEMENTS_EXPIRY'			=> 'تاریخ انقضای اطلاعیه',
	'BOARD_ANNOUNCEMENTS_EXPIRY_EXPLAIN'	=> 'با تنظیم تاریخ میتوانید تاریخ انقضایی برای اطلاعیه مشخص کنید ، اگر مایل به قرار دادن تاریخ نیستید آن را خالی بگذارید..',
	'BOARD_ANNOUNCEMENTS_EXPIRY_INVALID'	=> 'تاریخ انقضا اطلاعیه نا معتبر یا گذشته است.',
	'BOARD_ANNOUNCEMENTS_EXPIRY_FORMAT'		=> 'YYYY-MM-DD HH:MM',

	'BOARD_ANNOUNCEMENTS_TEXT'				=> 'متن اطلاعیه',
	'BOARD_ANNOUNCEMENTS_PREVIEW'			=> 'پیشنمایش اطلاعیه',

	'BOARD_ANNOUNCEMENTS_UPDATED'			=> 'اطلاعیه با موفقیت به روز رسانی شد.',
));
